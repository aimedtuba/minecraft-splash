This simple resource pack is designed to allow users to easily edit the the splash text on the Minecraft menu. 

For full usage instructions please see the accompanying How-To Geek tutorial, located at http://www.howtogeek.com/207640/





Attribution Notes: 

Icon made by Freepik (http://www.freepik.com) from Flaticon (http://www.flaticon.com) and is licensed by Creative Commons BY 3.0. 